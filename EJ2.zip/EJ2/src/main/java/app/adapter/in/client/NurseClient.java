package app.adapter.in.client;
<<<<<<< HEAD

import java.util.Scanner;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import app.domain.model.Patient;
import app.domain.model.User;
import app.domain.model.Visit;
import app.domain.model.Order;
import app.domain.model.enums.Role;
import app.domain.services.CreateVisit;
import app.domain.services.SearchOrdenByPatient;
import app.domain.services.SearchPatient;

@Controller
public class NurseClient {

	private static final String MENU = "Ingrese una opción \n" + "1. Registrar visita \n"
			+ "2. Consultar órdenes de un paciente \n" + "3. Consultar pacientes \n" + "4. Salir";

	private static Scanner reader = new Scanner(System.in);

	@Autowired
	private CreateVisit createVisit;

	@Autowired
	private SearchOrdenByPatient searchOrdenByPatient;

	@Autowired
	private SearchPatient searchPatient;

	@Autowired
	private User nurseUser;

	public NurseClient() {
		// Por simplicidad, aquí fijo un usuario enfermera
		this.nurseUser = new User();
		nurseUser.setRole(Role.NURSE);
		nurseUser.setFullName("Nurse System User");
	}

	public void session() {
		boolean session = true;
		while (session) {
			session = menu();
		}
	}

	private boolean menu() {
		try {
			System.out.println(MENU);
			String option = reader.nextLine();
			switch (option) {
			case "1": {
				Visit visit = readVisit();
				createVisit.create(nurseUser, visit);
				System.out.println("Visita registrada correctamente.");
				return true;
			}
			case "2": {
				Patient patient = readPatient();
				List<Order> orders = searchOrdenByPatient.search(patient, nurseUser);
				System.out.println("Órdenes encontradas: ");
				for (Order order : orders) {
					System.out.println(order);
				}
				return true;
			}
			case "3": {
				Patient patient = readPatient();
				List<Patient> patients = searchPatient.search(patient, nurseUser);
				System.out.println("Pacientes encontrados: ");
				for (Patient p : patients) {
					System.out.println(p);
				}
				return true;
			}
			case "4": {
				System.out.println("Cerrando sesión. Hasta luego.");
				return false;
			}
			default: {
				System.out.println("Opción no válida.");
				return true;
			}
			}
		} catch (Exception e) {
			System.out.println("Error: " + e.getMessage());
			return true;
		}
	}

	// Lectura de datos para crear una visita
	private Visit readVisit() {
		Visit visit = new Visit();
		System.out.println("Ingrese la temperatura del paciente:");
		visit.setTemperature(Double.parseDouble(reader.nextLine()));
		System.out.println("Ingrese el pulso del paciente:");
		visit.setPulse(Integer.parseInt(reader.nextLine()));
		System.out.println("Ingrese el nivel de oxígeno del paciente:");
		visit.setOxygenLevel(Integer.parseInt(reader.nextLine()));
		return visit;
	}

	// Lectura de datos para identificar a un paciente
	private Patient readPatient() {
		Patient patient = new Patient();
		System.out.println("Ingrese el ID del paciente:");
		patient.setPatientId(Long.parseLong(reader.nextLine()));
		System.out.println("Ingrese el nombre completo del paciente:");
		patient.setFullName(reader.nextLine());
		return patient;
	}
}
=======
 
import java.util.Scanner;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
 
import app.application.usecases.NurseUseCase;
import app.domain.model.Order;
import app.domain.model.OrderItem;
import app.domain.model.Patient;
import app.domain.model.Visit;
 
@Controller
public class NurseClient {
 
    private static final String MENU = """
            Ingrese una de las opciones:
            1. Registrar visita
            2. Buscar paciente
            3. Buscar órdenes por paciente
            4. Salir
            """;
 
    private static final Scanner reader = new Scanner(System.in);
 
    @Autowired
    private NurseUseCase nurseUseCase;
 
    public void session() {
        boolean session = true;
        while (session) {
            session = menu();
        }
    }
 
    private boolean menu() {
        try {
            System.out.println(MENU);
            String option = reader.nextLine();
            switch (option) {
                case "1" -> {
                    Visit visit = readVisit();
                    nurseUseCase.createVisit(visit);
                    return true;
                }
                case "2" -> {
                    Patient patient = readPatient();
                    nurseUseCase.searchPatient(patient);
                    return true;
                }
                case "3" -> {
                    Patient patient = readPatient();
                    nurseUseCase.searchOrdenByPatient(patient);
                    return true;
                }
                case "4" -> {
                    System.out.println("Hasta luego. Cerrando sesión...");
                    return false;
                }
                default -> {
                    System.out.println("Ingrese una opción válida.");
                    return true;
                }
            }
        } catch (Exception e) {
            System.out.println("⚠️ Error: " + e.getMessage());
            return true;
        }
    }
 
    // === Métodos auxiliares ===
 
    private Visit readVisit() {
        Visit visit = new Visit();
 
        System.out.println("Ingrese la presión arterial (ej: 120/80):");
        visit.setBloodPressure(reader.nextLine());
 
        System.out.println("Ingrese la temperatura (°C):");
        visit.setTemperature(Double.parseDouble(reader.nextLine()));
 
        System.out.println("Ingrese el pulso (lpm):");
        visit.setPulse(Integer.parseInt(reader.nextLine()));
 
        System.out.println("Ingrese el nivel de oxígeno (%):");
        visit.setOxygenLevel(Integer.parseInt(reader.nextLine()));
 
        System.out.println("Ingrese las observaciones de la visita:");
        visit.setObservations(reader.nextLine());
 
        return visit;
    }
 
    private Patient readPatient() {
        Patient patient = new Patient();
 
        System.out.println("Ingrese el ID del paciente:");
        patient.setPatientId(Long.parseLong(reader.nextLine()));
 
        System.out.println("Ingrese el nombre completo:");
        patient.setFullName(reader.nextLine());
 
        return patient;
    }
 
    private Order readOrder() {
        Order order = new Order();
 
        System.out.println("Ingrese el ID del paciente:");
        order.setPatientId(reader.nextLine());
 
        System.out.println("Ingrese el ID del doctor:");
        order.setDoctorId(reader.nextLine());
 
        // La fecha de creación puede asignarse automáticamente en la capa de dominio
 
        boolean addMore = true;
        while (addMore) {
            OrderItem item = readOrderItem();
            order.addItem(item);
 
            System.out.println("¿Desea agregar otro ítem? (s/n):");
            String response = reader.nextLine();
            addMore = response.equalsIgnoreCase("s");
        }
 
        return order;
    }
 
    private OrderItem readOrderItem() {
        System.out.println("Ingrese el tipo de ítem (Medicamento/Procedimiento/Ayuda):");
        String type = reader.nextLine();
 
        System.out.println("Ingrese la descripción del ítem:");
        String description = reader.nextLine();
 
        System.out.println("Ingrese los detalles:");
        String details = reader.nextLine();
 
        return new OrderItem(type, description, details);
    }
}
 
>>>>>>> 39c238734a14a717ea9c851412ec64e52399b237
