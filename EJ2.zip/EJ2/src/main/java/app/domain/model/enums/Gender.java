package app.domain.model.enums;

public enum Gender {
	MALE,
	FEMALE,
	OTHER

}
