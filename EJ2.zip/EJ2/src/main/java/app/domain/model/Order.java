package app.domain.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Order {
<<<<<<< HEAD
	private long orderNumber;
=======
	private int orderNumber;
>>>>>>> 39c238734a14a717ea9c851412ec64e52399b237
	private String patientId;
	private String doctorId;
	private LocalDate creationDate;
	private List<OrderItem> items = new ArrayList<>();

<<<<<<< HEAD
	public long getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(long orderNumber) {
=======
	public int getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(int orderNumber) {
>>>>>>> 39c238734a14a717ea9c851412ec64e52399b237
		this.orderNumber = orderNumber;
	}

	public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public String getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(String doctorId) {
		this.doctorId = doctorId;
	}

	public LocalDate getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(LocalDate creationDate) {
		this.creationDate = creationDate;
	}

	public List<OrderItem> getItems() {
		return items;
	}

	public void addItem(OrderItem item) {
		this.items.add(item);
	}
}
