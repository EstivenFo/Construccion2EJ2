package app.domain.model;

import app.domain.model.enums.Gender;
import app.domain.model.enums.Role;

public class User {
	private String fullName;
<<<<<<< HEAD
	private String idCard;
=======
	private long idCard;
>>>>>>> 39c238734a14a717ea9c851412ec64e52399b237
	private String email;
	private long phone;
	private long birthDate;
	private String address;
	private Role role;
	private Gender gender;
	
<<<<<<< HEAD

=======
>>>>>>> 39c238734a14a717ea9c851412ec64e52399b237
	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

<<<<<<< HEAD
	public String getIdCard() {
		return idCard;
	}

	public void setIdCard(String idCard) {
=======
	public long getIdCard() {
		return idCard;
	}

	public void setIdCard(long idCard) {
>>>>>>> 39c238734a14a717ea9c851412ec64e52399b237
		this.idCard = idCard;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getPhone() {
		return phone;
	}

	public void setPhone(long phone) {
		this.phone = phone;
	}

	public long getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(long birthDate) {
		this.birthDate = birthDate;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

<<<<<<< HEAD
}
=======
	
	}


>>>>>>> 39c238734a14a717ea9c851412ec64e52399b237
