package app.domain.model.enums;

public enum Role {
	MEDIC,
	NURSE,
	ADMINISTRATIVESTAFF,
	HUMANRESOURCES
}
