package app.domain.model.enums;

public enum Status {
	SCHEDULED, 
	CANCELED, 
<<<<<<< HEAD
	PENDING,
=======
>>>>>>> 39c238734a14a717ea9c851412ec64e52399b237
	COMPLETED
}
