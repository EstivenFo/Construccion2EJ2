package app.domain.services;

import java.time.LocalDateTime;
import java.util.List;
<<<<<<< HEAD

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

=======
>>>>>>> 39c238734a14a717ea9c851412ec64e52399b237
import app.domain.model.Appointment;
import app.domain.ports.AppointmentPort;
import app.domain.model.enums.Role;
import app.domain.model.User;

<<<<<<< HEAD
@Service
public class CreateAppointment {
	@Autowired
=======
public class CreateAppointment {

>>>>>>> 39c238734a14a717ea9c851412ec64e52399b237
	private AppointmentPort appointmentPort;

	// Crear una nueva cita
	public void create(Appointment appointment, User user) throws Exception {
		// Validar que el objeto no sea nulo
		if (appointment == null) {
			throw new IllegalArgumentException("La cita no puede ser nula");
		}

		// Validar fecha de la cita
		LocalDateTime appointmentDate = appointment.getDate();
		if (appointmentDate == null || appointmentDate.isBefore(LocalDateTime.now())) {
			throw new Exception("La fecha de la cita no es válida");
		}

		// Validar que el doctor no tenga otra cita en la misma fecha/hora
		List<Appointment> doctorAppointments = appointmentPort.searchByDoctorId(appointment.getDoctor());

		for (Appointment appt : doctorAppointments) {
			if (appt.getDate().equals(appointmentDate)) {
				throw new Exception("El doctor ya tiene una cita en esa fecha y hora");
			}
			if (!(user.getRole() == Role.MEDIC || user.getRole() == Role.HUMANRESOURCES)) {
			    throw new SecurityException("Solo el personal administrador puede crear citas");
			}
		}

		// Guardar la cita
		appointmentPort.save(appointment);
	}
}
